import React, { useState } from "react";
import Card from "./Card";
import Navbar from "./Navbar";
import img3 from "../images/img3.jpg";
import "../cssFiles/Home.css"; // Import the CSS file for styling
import logo from "../images/logo2.jpg"; // Import the logo image
import CartSummary from "./CartSummary"; // Import the CartSummary component

const Home = () => {
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState([]);

  const toggleCart = () => {
    setCartOpen(!cartOpen);
  };

  const addToCart = (newItem) => {
    const existingItemIndex = cartItems.findIndex(
      (item) => item.product.id === newItem.product.id
    );

    if (existingItemIndex !== -1) {
      // Item already exists in cart, update quantity and total cost
      const updatedItems = [...cartItems];
      updatedItems[existingItemIndex].quantity += 1;
      updatedItems[existingItemIndex].totalCost += parseFloat(
        newItem.product.price
      );
      setCartItems(updatedItems);
    } else {
      // Item does not exist in cart, add new item
      setCartItems([
        ...cartItems,
        {
          quantity: 1,
          product: newItem.product,
          totalCost: parseFloat(newItem.product.price),
        },
      ]);
    }
  };

  const removeFromCart = (productId) => {
    const updatedItems = cartItems.filter(
      (item) => item.product.id !== productId
    );
    setCartItems(updatedItems);
  };

  const products = [
    {
      id: 1,
      image: img3, // Use the imported image directly
      name: "Product 1",
      description: "Description for Product 1.",
      price: "10",
    },
    {
      id: 2,
      image: img3, // Use the imported image directly
      name: "Product 2",
      description: "Description for Product 2.",
      price: "20",
    },
    {
      id: 3,
      image: img3, // Use the imported image directly
      name: "Product 3",
      description: "Description for Product 3.",
      price: "30",
    },
    {
      id: 4,
      image: img3, // Use the imported image directly
      name: "Product 4",
      description: "Description for Product 4.",
      price: "40",
    },
    {
      id: 5,
      image: img3, // Use the imported image directly
      name: "Product 5",
      description: "Description for Product 5.",
      price: "50",
    },
    {
      id: 6,
      image: img3, // Use the imported image directly
      name: "Product 6",
      description: "Description for Product 6.",
      price: "60",
    },
    {
      id: 7,
      image: img3, // Use the imported image directly
      name: "Product 7",
      description: "Description for Product 7.",
      price: "70",
    },
    {
      id: 8,
      image: img3, // Use the imported image directly
      name: "Product 8",
      description: "Description for Product 8.",
      price: "80",
    },
    {
      id: 9,
      image: img3, // Use the imported image directly
      name: "Product 9",
      description: "Description for Product 9.",
      price: "90",
    },
  ];

  return (
    <>
      <Navbar toggleCart={toggleCart} cartItems={cartItems} />
      <div className="home-container">
        <img src={logo} alt="Website Logo" className="home-logo" />
        <h1 className="home-slogan">Your Slogan Here</h1>
        <p className="home-description">
          This is a short description about the website. Explain what the
          website is about, its purpose, and any other relevant information that
          visitors might find useful.
        </p>
        <div className="products-container">
          {products.map((product) => (
            <Card key={product.id} product={product} addToCart={addToCart} />
          ))}
        </div>
        {cartOpen && (
          <CartSummary
            cartItems={cartItems}
            closeCart={() => setCartOpen(false)}
            removeFromCart={removeFromCart}
          />
        )}
      </div>
      <button className="cart-toggle" onClick={toggleCart}>
        {cartOpen ? "Close Cart" : "Open Cart"}
      </button>
    </>
  );
};

export default Home;
