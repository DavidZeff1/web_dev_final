import React from "react";
import "../cssFiles/CartSummary.css"; // Import the CSS file for styling

const CartSummary = ({ cartItems, closeCart, removeFromCart }) => {
  return (
    <div className="cart-summary">
      <button className="close-cart" onClick={closeCart}>Close</button>
      <h2>Shopping Cart</h2>
      {cartItems.map((item) => (
        <div key={item.product.id} className="cart-item">
          <img src={item.product.image} alt={item.product.name} className="cart-item-image" />
          <div className="cart-item-details">
            <h3>{item.product.name}</h3>
            <p>Quantity: {item.quantity}</p>
            <p>Total Cost: ${item.totalCost.toFixed(2)}</p>
            <button onClick={() => removeFromCart(item.product.id)} className="remove-button">Remove</button>
          </div>
        </div>
      ))}
      {cartItems.length === 0 && <p>Your cart is empty.</p>}
    </div>
  );
};

export default CartSummary;

