import React from "react";
import "../cssFiles/Card.css"; // Import the CSS file for styling

const Card = ({ product, addToCart }) => {
  const handleAddToCart = () => {
    addToCart({
      product: product,
      quantity: 1, // Initial quantity added to cart
      totalCost: parseFloat(product.price), // Initial total cost (price of one item)
    });
  };

  return (
    <div className="card">
      <img src={product.image} alt={product.name} className="card-image" />
      <div className="card-content">
        <h2 className="card-title">{product.name}</h2>
        <p className="card-description">{product.description}</p>
        <span className="card-price">${product.price}</span>
        <button className="button" onClick={handleAddToCart}>
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default Card;
