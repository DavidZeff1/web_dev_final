import React from "react";
import { FaShoppingCart, FaHome } from "react-icons/fa";
import "../cssFiles/navbar.css";

const Navbar = ({ toggleCart, cartItems }) => {
  return (
    <nav className="navbar">
      <div className="navbar-logo">Foot Walker</div>
      <div className="navbar-icons">
        <a href="/home">
          <FaHome size={20} />
        </a>
        <button className="cart-icon" onClick={toggleCart}>
          <FaShoppingCart size={20} />
          {cartItems.length > 0 && (
            <span className="cart-badge">{cartItems.length}</span>
          )}
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
